(function ($) {
    "use strict";
    $.fn.chatbot = function () {
		
		//var url =window.location.href;
		
		this.html('<iframe src="chatbotMasaustu.html" class="chatbot-iframe" id="chatbot_iframe" style="border:none;height:100%;width:100%;"></iframe>');
		
		
		var isMobile =  screen.width;
		if(isMobile >416)
		{
				this.css({
				'position': 'fixed',
				'right': '10px',				
				/*'height': '101px',*/
				'height': '180px',
				'width': '215px',
				/*'bottom': '15px',*/
				'bottom': '0px',
				'z-index': '10000'
			});
		}
		else{
			
			this.css({
				'position': 'fixed',
				'right': '10px',
				'height': '171px',
				'width': '180px',
				'bottom': '4px',
				'z-index': '10000'
			});
		}
		var  a = $("body").find('.chatbot-iframe body #chat-window #chat-robot');
	
    }
})(jQuery);
$(document).ready(function () {

	$('body').append('<div id="chat-ekrani"></div>');
    $("#chat-ekrani").chatbot();

	
	//console.log(urlS);
	//$("#chat-robot").trigger("click");
	
	
var eventMethod = window.addEventListener
			? "addEventListener"
			: "attachEvent";
	var eventer = window[eventMethod];
	var messageEvent = eventMethod === "attachEvent"
		? "onmessage"
		: "message";
	eventer(messageEvent, function (e) {	
	var width = (window.innerWidth < 0) ? window.innerWidth : screen.width;
		if (e.data === "buyult" || e.message === "buyult") 
		{
			if(width>416)
			{
			//$('#chat-ekrani').css("height","585px");
			//$('#chat-ekrani').css("width","420px !important");
			$("#chat-ekrani").css("bottom","0px");
			$("#chat-ekrani").css("right","0px");
			$('#chat-ekrani').css("height","100%");
			$('#chat-ekrani').css("width","100%");
			}else{
			$("#chat-ekrani").css("bottom","0px");
			$("#chat-ekrani").css("right","0px");
			$('#chat-ekrani').css("height","100%");
			$('#chat-ekrani').css("width","100%");
			}
		}else{
			var isMobile =  screen.width;
			if(isMobile > 416)
			{
				/*$('#chat-ekrani').css("height","50px");
				$('#chat-ekrani').css("width","160px");*/
				$('#chat-ekrani').css("height","180px");
				$('#chat-ekrani').css("width","215px");
				$("#chat-ekrani").css("bottom","0px");
				$("#chat-ekrani").css("right","10px");
			}else
			{
				
				$('#chat-ekrani').css("height","171px");
				$('#chat-ekrani').css("width","180px");
				$("#chat-ekrani").css("bottom","4px");
				$("#chat-ekrani").css("right","10px");
			}
			
		}
		
	});
});